package com.example.mainproject

import android.annotation.SuppressLint
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.ListView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class CustomViewDemo : AppCompatActivity() {
    lateinit var edt1:EditText
    lateinit var edt2:EditText
    lateinit var btn:Button
    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_custom_view_demo)
        var listView=findViewById<ListView>(R.id.custom_list_view)
        var list= mutableListOf<ModelDomo>()

        edt1=findViewById(R.id.edt1)
        edt2=findViewById(R.id.edt2)
        btn=findViewById(R.id.add)
        btn.setOnClickListener(){
        list.add(ModelDomo(edt1.text.toString(),edt2.text.toString(),R.drawable.facebook))
        /*list.add(ModelDomo("Whatsapp","Whatsapp description",R.drawable.whatsapp))
        list.add(ModelDomo("Instagram","Instagram descripiton",R.drawable.instagram))
        list.add(ModelDomo("Titok","Tiktok description",R.drawable.titok))*/
        listView.adapter=MyAdapter(this,R.layout.custom_look_file,list)}
    }
}