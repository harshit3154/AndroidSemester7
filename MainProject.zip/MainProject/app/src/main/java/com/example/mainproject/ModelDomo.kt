package com.example.mainproject

class ModelDomo(val title:String,val subtitle:String,val img:Int) {
}