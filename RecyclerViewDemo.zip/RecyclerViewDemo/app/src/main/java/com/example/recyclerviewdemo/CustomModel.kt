package com.example.recyclerviewdemo

class CustomModel(var title:String,var image:Int) {
}